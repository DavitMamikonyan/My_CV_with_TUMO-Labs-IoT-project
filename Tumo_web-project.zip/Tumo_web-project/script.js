/**
 * script.js
 * Handles UI interactions (tabs) and visualization logic.
 * Relies on read_data.js for data fetching.
 */

// Flag to ensure charts are only initialized once when the tab is visible
let chartsInitialized = false;

document.addEventListener('DOMContentLoaded', () => {
    initTabs();
    // Charts are initialized in the tab click handler to ensure visibility
});

// Tab Switching Logic
function initTabs() {
    const tabBtns = document.querySelectorAll('.tab-btn');
    const tabContents = document.querySelectorAll('.tab-content');

    tabBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            // Remove active class from all
            tabBtns.forEach(b => b.classList.remove('active'));
            tabContents.forEach(c => c.classList.remove('active'));

            // Add active class to clicked
            btn.classList.add('active');
            const tabId = btn.getAttribute('data-tab');
            const activeContent = document.getElementById(tabId);
            activeContent.classList.add('active');

            // Initialize charts ONLY when the chart tab is clicked and visible
            if (tabId === 'tab-charts' && !chartsInitialized) {
                // Small timeout to ensure the DOM has updated display:block before Chart.js measures dimensions
                setTimeout(() => {
                    initAirQualityData();
                }, 100);
            }
        });
    });
}

// Chart Logic
async function initAirQualityData() {
    // Check if fetchAirQualityData exists (from read_data.js)
    if (typeof fetchAirQualityData !== 'function') {
        console.error("fetchAirQualityData function not found. Ensure read_data.js is loaded.");
        return;
    }

    const container = document.getElementById('charts-container');
    
    // Fetch data
    const data = await fetchAirQualityData();
    
    // 1. Handle Empty or Invalid Data Structure
    if (!data || !data.readings || !Array.isArray(data.readings) || data.readings.length === 0) {
        container.innerHTML = '<p style="text-align:center; padding: 2rem;">No data available or invalid JSON format.</p>';
        return;
    }

    // If we get here, data is good. Mark initialized.
    chartsInitialized = true;
    const readings = data.readings;
    
    // Parse dates and prepare axis labels
    const labels = readings.map(r => {
        try {
            const date = new Date(r.timestamp);
            return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        } catch (e) {
            return r.timestamp;
        }
    });

    // Helper to extract data array
    const getData = (key) => readings.map(r => r[key]);

    // Common Chart Options for Dark Theme
    const commonOptions = {
        responsive: true,
        maintainAspectRatio: false,
        interaction: {
            mode: 'index',
            intersect: false,
        },
        scales: {
            x: {
                grid: { 
                    display: false, // Cleaner look without vertical grid lines
                    drawBorder: false
                },
                ticks: { 
                    display: true, // Show ticks so we can display first/last
                    color: '#b0b0b0',
                    font: { size: 11 },
                    autoSkip: false, // Don't skip ticks automatically, we handle it manually
                    maxRotation: 0,
                    callback: function(value, index, values) {
                        // Display only the first and last labels
                        if (index === 0 || index === values.length - 1) {
                            return this.getLabelForValue(value);
                        }
                        return ''; // Hide all intermediate labels
                    }
                },
                title: {
                    display: true,
                    text: 'Time', // Label for X-axis
                    color: '#b0b0b0',
                    font: {
                        size: 14,
                        weight: 'bold'
                    },
                    padding: { top: 10 }
                }
            },
            y: {
                grid: { 
                    color: 'rgba(255, 255, 255, 0.1)', // Faint grid
                    borderDash: [5, 5] // Dashed grid lines
                },
                ticks: { 
                    color: '#b0b0b0',
                    font: { size: 11 }
                },
                border: {
                    display: false // Hide the main Y axis line
                }
            }
        },
        plugins: {
            legend: {
                labels: { 
                    color: '#ffffff',
                    usePointStyle: true,
                    boxWidth: 8,
                    font: { family: "'Segoe UI', sans-serif" }
                }
            },
            tooltip: {
                mode: 'index',
                intersect: false,
                backgroundColor: 'rgba(30,30,30,0.9)',
                titleColor: '#fff',
                bodyColor: '#ccc',
                borderColor: 'rgba(255,255,255,0.1)',
                borderWidth: 1,
                padding: 10,
                callbacks: {
                    // Custom title to show "Time: [Value]"
                    title: (context) => 'Time: ' + context[0].label
                }
            }
        },
        elements: {
            line: {
                tension: 0.4, // Smooth curves
                borderWidth: 2
            },
            point: {
                radius: 0, // Hide points for a modern look
                hitRadius: 20, // Ensure hover interaction still works
                hoverRadius: 6
            }
        }
    };

    // Define Charts to render
    const chartConfigs = [
        { id: 'tempChart', label: 'Temperature (°C)', data: getData('temperature'), color: '#ff5252' },
        { id: 'pressureChart', label: 'Pressure (hPa)', data: getData('pressure'), color: '#448aff' },
        { id: 'humidityChart', label: 'Humidity (%)', data: getData('humidity'), color: '#69f0ae' },
        { id: 'altitudeChart', label: 'Altitude (m)', data: getData('altitude'), color: '#e040fb' },
        { id: 'co2Chart', label: 'CO2 (ppm)', data: getData('co2ppm'), color: '#ffd740' },
        { id: 'tvocChart', label: 'TVOC Index', data: getData('tvoc_index'), color: '#ffab40' }
    ];

    // Render Simple Charts with Gradients
    chartConfigs.forEach(config => {
        const canvas = document.getElementById(config.id);
        if (canvas) {
            const ctx = canvas.getContext('2d');
            
            // Create a gradient for the fill
            let gradient = config.color; // fallback
            try {
                gradient = ctx.createLinearGradient(0, 0, 0, 300);
                // 8-digit hex codes (RRGG BBAA) for transparency
                gradient.addColorStop(0, config.color + '90'); // High opacity at top
                gradient.addColorStop(1, config.color + '00'); // Fade out at bottom
            } catch(e) {
                console.warn("Gradient creation failed, using solid color");
            }

            new Chart(canvas, {
                type: 'line',
                data: {
                    labels: labels,
                    datasets: [{
                        label: config.label,
                        data: config.data,
                        borderColor: config.color,
                        backgroundColor: gradient,
                        fill: true
                    }]
                },
                options: commonOptions
            });
        }
    });

    // Render Complex PM Chart (Multi-line)
    const pmCanvas = document.getElementById('pmChart');
    if (pmCanvas) {
        new Chart(pmCanvas, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [
                    { label: 'PM 1.0', data: getData('pm1_0'), borderColor: '#18ffff', backgroundColor: '#18ffff10', fill: true },
                    { label: 'PM 2.5', data: getData('pm2_5'), borderColor: '#b2ff59', backgroundColor: '#b2ff5910', fill: true },
                    { label: 'PM 4.0', data: getData('pm4_0'), borderColor: '#ff4081', backgroundColor: '#ff408110', fill: true },
                    { label: 'PM 10', data: getData('pm10'), borderColor: '#7c4dff', backgroundColor: '#7c4dff10', fill: true }
                ]
            },
            options: commonOptions
        });
    }
}